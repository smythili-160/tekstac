import java.util.Scanner;
public class UserInterface 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//Fill code here 
		System.out.println("Enter the ticket Id");
		Long ticketId=sc.nextLong();
		long ticket=ticketId;
		int length=Long.toString(ticketId).length();
		System.out.println("Enter the unlucky code");
		short unluckyCode=sc.nextShort();
		int count=0;
		for(int i=1;i<=length;i++) {
			int digit=(int)(ticketId%10);
			ticketId=ticketId/10;
			if(digit==unluckyCode) {
				count++;
			}	
		}
		if(count==0) {
			System.out.println(ticket+" is lucky ticket");			
		}
		else if(count<3){
			System.out.println(ticket+" is partially lucky");			
		}
		else {
			System.out.println(ticket+" is unlucky ticket");			
			
		}
	}
}