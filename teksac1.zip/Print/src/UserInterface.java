
public class UserInterface {

	public static void main(String[] args) 
	{
		//Fill your code here
		System.out.println("Thank you for your order");
	}

}
