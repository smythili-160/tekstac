import java.util.Scanner;

public class UserInterface {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the name");
        String name = sc.next();
        
        System.out.println("Enter the number of rooms you needed");
        int numberOfRooms = sc.nextInt();
        
        // Check if the number of rooms is valid
        if (numberOfRooms <= 0) {
            System.out.println("Please enter a valid number");
            numberOfRooms = sc.nextInt();
        } 
            System.out.println("Enter the phone number");
            long phoneNum = sc.nextLong();
            System.out.println("Pay Rs. " + (numberOfRooms * 500) + " for booking");
            System.out.println("Your booking has been confirmed");
        
        
        sc.close();
    }
}
