import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		//Fill the code here
		System.out.println("Enter the day");
		int days=sc.nextInt();
		if(days<=0 || days>30) {
			System.out.println(days+" is invalid day");
			return;
		}
		else {
		int[] eggs=new int[days];
		eggs[0]=1;
		if(days>1) {
		eggs[1]=2;
		int sum=eggs[0]+eggs[1];
	    for(int i=2;i<days;i++) {
	    	eggs[i]=2*eggs[i-1]+eggs[i-2];
	    	
	    }
		}
	    System.out.println("Number of eggs in "+days+"th day is "+eggs[days-1]);
		
		
	}
		sc.close();
	}

}
