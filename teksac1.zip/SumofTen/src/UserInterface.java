import java.util.Scanner;
public class UserInterface {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//Fill code here 
		System.out.println("Enter the number");
		int num= sc.nextInt();
		int sum=0;
		if(num<0) {
			System.out.println(num+" is a negative number");
		}
		else {
		for(int i=1;i<=10;i++) {
			sum=sum+num;
			num++;
		}
		System.out.println("The sum of ten numbers is "+sum);
		}
	}
}
