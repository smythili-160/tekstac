import java.util.Scanner;
 public class UserInterface{
    public static void main(String args[])
    {
    	Scanner sc = new Scanner(System.in);
        System.out.println("Enter the length of the room(in m)");
        double length = sc.nextDouble();
        if (length <= 0) {
            System.out.println("Invalid length");
            return;
        }
        System.out.println("Enter the breadth of the room(in m)");
        double breadth = sc.nextDouble();
        if (breadth <= 0) {
            System.out.println("Invalid breadth");
            return;
        }
        System.out.println("Enter the plant area of a single plant(in cm2)");
        double plantArea = sc.nextDouble();
        if (plantArea <= 0) {
            System.out.println("Invalid plant area");
            return;
        }
        double floorArea = length * breadth * 100 * 100;
        double totalPlants = floorArea / plantArea;
        double x = totalPlants % 10;
        if (x <= 5 || x==0) {
       	 totalPlants = Math.floor(totalPlants / 10) * 10;
        } else {
            totalPlants = Math.ceil(totalPlants / 10) * 10;
        }
        double oxygen = totalPlants * 0.9;
        System.out.println("Total number of plants is " + (int) totalPlants);
        System.out.printf("Total oxygen production is %.2f litres\n", oxygen);
   	}
    
    }

