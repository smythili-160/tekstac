import java.util.Scanner;
public class UserInterface
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//Fill code here 
		System.out.println("Enter Alex points");
		int alex=sc.nextInt();
		System.out.println("Enter Nikil points");
		int nikhil=sc.nextInt();
		System.out.println("Enter Sam points");
        int sam=sc.nextInt();
        if(alex<=0 || alex>50){ 
        	System.out.println(alex+" is an invalid number");
        	return;
        	
        }
        else if(nikhil<=0 || nikhil>50) {
        	System.out.println(nikhil+" is an invalid number");
        	return;
        	
        }
        else if(sam<=0 || sam>50) {
         	System.out.println(sam+" is an invalid number");
         	return;
        	
        }
        if (alex==nikhil || nikhil==sam) {
        	System.out.println("The game is a tie");
        }
        else {
        	int max=Math.max(Math.max(alex, sam),nikhil);
            if(alex==max) {
            	System.out.println("Alex scored "+max+" points and won the game");
            }
            else if(nikhil==max) {
            	System.out.println("Nikhil scored "+max+" points and won the game");
            }
            else if(sam==max) {
            	System.out.println("Sam scored "+max+" points and won the game");
            }
        }
        
    }
}
