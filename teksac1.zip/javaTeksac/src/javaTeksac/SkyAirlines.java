package javaTeksac;
import java.util.Scanner;
public class SkyAirlines {
	
		 public static void printmsg(String name ,String source ,String destination) {
			 System.out.println("Dear" +name+" welcome onboard with service from" +source+"to " +destination+ "Tahnkyou for choosingSkyAirline.enjoy your flight");
		 }
			public static void main(String[]args) {
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter name");
				String name = sc.nextLine();
				System.out.println("Enter source");
				String source = sc.nextLine();
				System.out.println("Enter destination");
				String destination =sc.nextLine();
				printmsg(name,source,destination);
			}
	 
	}
	 

