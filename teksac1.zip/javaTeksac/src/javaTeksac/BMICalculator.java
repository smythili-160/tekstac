package javaTeksac;

import java.util.Scanner;

public class BMICalculator {
	public static void main(String args[])
    {
    	Scanner sc = new Scanner(System.in);
    	System.out.println("Enter weight in kg");
    	float weight=sc.nextFloat();
    	System.out.println("Enter height in cm");
    	float height=sc.nextFloat();
    	height=height/100;
    	float bmi=weight/(height*height);
    	String roundedbmi = String.format("%.2f", bmi);
    	if(bmi>=25) {
    	String roundedWeight = String.format("%.2f", bmi-18.5);
    	System.out.println("Your BMI is "+roundedbmi+". You are overweight");
    	System.out.println("Reduce "+roundedWeight+" kg to be fit");
    	}
    	else if(bmi<25 && bmi>=18.5) {
    	System.out.println("Your BMI is "+roundedbmi+". You are fit and healthy");
    	}
    	else if(bmi<18.5) {
    		String roundedWeight = String.format("%.2f", 18.5-bmi);
    		System.out.println("Your BMI is "+roundedbmi+". You are overweight");
    		System.out.println("Gain "+roundedWeight+" kg to be fit");
    	}
    	sc.close();
    }

}
